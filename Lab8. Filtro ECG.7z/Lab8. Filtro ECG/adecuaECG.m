%ecg2 = ecg_1p(F,:);
F=find(diff(ecg_1p(:,1)));
ecg2 = ecg_1p(F,:);
ecg2(:,1) = ecg2(:,1)-min(ecg2(:,1));
%t = timeseries(ecg(:,2),ecg(:,1));
ecg.signals.values = ecg2(:,2);
ecg.time=[];
ecg.signals.dimensions=1;

%%
ecg1_p = r';
%F=find(diff(ecg1_p(:)));
%ecg2 = ecg1_p(F);
%t = timeseries(ecg(:,2),ecg(:,1));
ecg.signals.values = ecg1_p;
ecg.time=[];
ecg.signals.dimensions=1;


%% Señal 12
archivo = 'js620.csv';
columna = 2;
intervalo = 1:599;
a = csvread('ECG1kHz.csv',columna,0);

y = a(:,2)';
L = numel(y);
t = a(:,1)';
duracion = t(end) - t(1);
Fs = L/duracion;
Ts = 1/Fs;
fmaxima = Fs/2;

ecg12.signals.values = y';
ecg12.time=[];
ecg12.signals.dimensions=1;