%% Frecuencia de muestreo para 
duracion_ecg1p = ecg_1p(end,1)-ecg_1p(1,1);
Fs_ecg1p = 1544/duracion_ecg1p;
Ts_ecg1p = 1/Fs_ecg1p;
%%
numel(ecg.signals.values);
ecg_out=(out.ecg_filt.Data);
duracion = out.ecg_filt.Time(end) - out.ecg_filt.Time(1);
plot(out.ecg_filt.Data)

